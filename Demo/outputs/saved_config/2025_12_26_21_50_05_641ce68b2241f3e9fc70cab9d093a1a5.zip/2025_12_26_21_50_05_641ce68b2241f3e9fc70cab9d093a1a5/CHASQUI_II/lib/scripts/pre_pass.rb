require 'cosmos'
require 'cosmos/script'

def pre_pass_checks(pass_start_time, pass_duration, max_elevation)
  puts "="*70
  puts "INICIANDO VERIFICACIÓN PRE-PASE"
  puts "Hora de inicio: #{pass_start_time.strftime('%Y-%m-%d %H:%M:%S')}"
  puts "Duración estimada: #{pass_duration} minutos"
  puts "Elevación máxima: #{max_elevation}°"
  puts "="*70
  
  all_ok = true
  
  # 1. Verificar conexión con GNU Radio
  begin
    status = get_interface_names()
    if status.include?("GNURADIO_INTERFACE")
      interface_state = get_interface_info("GNURADIO_INTERFACE")
      if interface_state['state'] == 'CONNECTED'
        puts "✓ Interfaz GNU Radio: CONECTADA"
      else
        puts "✗ Interfaz GNU Radio: DESCONECTADA"
        puts "  Intentando reconectar..."
        connect_interface("GNURADIO_INTERFACE")
        wait(5)
        all_ok = false
      end
    else
      puts "✗ ERROR: Interfaz GNU Radio no existe"
      all_ok = false
    end
  rescue => e
    puts "✗ Error verificando GNU Radio: #{e.message}"
    all_ok = false
  end
  
  # 2. Verificar rotctld (Hamlib)
  begin
    response = `echo "p" | nc -w 1 localhost 4533 2>&1`
    if response.include?("RPRT 0") || response =~ /\d+\.\d+/
      puts "✓ Rotctld (Hamlib): FUNCIONANDO"
    else
      puts "✗ ERROR: rotctld no responde"
      puts "  Respuesta: #{response}"
      all_ok = false
    end
  rescue => e
    puts "✗ Error verificando rotctld: #{e.message}"
    all_ok = false
  end
  
  # 3. Verificar espacio en disco
  begin
    disk_output = `df -h #{Cosmos::USERPATH}/outputs/logs 2>&1`
    disk_space = disk_output.split("\n").last.split[3]
    
    # Convertir a GB para verificar
    if disk_space =~ /(\d+\.?\d*)G/
      space_gb = $1.to_f
      if space_gb >= 1.0
        puts "✓ Espacio disponible: #{disk_space}"
      else
        puts "⚠ ADVERTENCIA: Poco espacio en disco (#{disk_space})"
      end
    else
      puts "✓ Espacio disponible: #{disk_space}"
    end
  rescue => e
    puts "⚠ No se pudo verificar espacio en disco: #{e.message}"
  end
  
  # 4. Verificar estado del satélite (último beacon conocido)
  begin
    voltage = tlm("CHASQUI_II BEACON MAIN_BATT_VOLT")
    mode = tlm("CHASQUI_II BEACON SAT_CURR_MODE")
    temp = tlm("CHASQUI_II BEACON TEMP_CDH")
    boot_count = tlm("CHASQUI_II BEACON BOOT_COUNTER")
    
    puts "\n--- ÚLTIMO ESTADO CONOCIDO DEL SATÉLITE ---"
    puts "  Voltaje batería: #{voltage}V"
    puts "  Modo: #{mode}"
    puts "  Temperatura CDH: #{temp}°C"
    puts "  Boot counter: #{boot_count}"
    puts "-------------------------------------------\n"
    
    # Verificar condiciones críticas
    if voltage < 7.0
      puts "⚠ ADVERTENCIA: Voltaje bajo (#{voltage}V)"
    end
    
    if temp > 45 || temp < -10
      puts "⚠ ADVERTENCIA: Temperatura fuera de rango (#{temp}°C)"
    end
    
  rescue => e
    puts "⚠ No hay telemetría reciente disponible"
  end
  
  # 5. Iniciar logging
  begin
    unless cmd_log_running?()
      start_cmd_log()
      puts "✓ Command logging iniciado"
    else
      puts "✓ Command logging ya estaba activo"
    end
    
    unless tlm_log_running?()
      start_tlm_log()
      puts "✓ Telemetry logging iniciado"
    else
      puts "✓ Telemetry logging ya estaba activo"
    end
  rescue => e
    puts "✗ Error iniciando logging: #{e.message}"
    all_ok = false
  end
  
  # 6. Preparar archivos de salida
  timestamp = pass_start_time.strftime("%Y%m%d_%H%M%S")
  pass_dir = "#{Cosmos::USERPATH}/outputs/passes/pass_#{timestamp}"
  
  begin
    Dir.mkdir(pass_dir) unless Dir.exist?(pass_dir)
    set_global_variable("CURRENT_PASS_DIR", pass_dir)
    puts "✓ Directorio de pase creado: #{pass_dir}"
  rescue => e
    puts "✗ Error creando directorio: #{e.message}"
    all_ok = false
  end
  
  # 7. Inicializar contador de paquetes
  set_global_variable("PACKET_COUNT", 0)
  set_global_variable("PASS_START_TIME", pass_start_time)
  set_global_variable("PASS_AOS", nil)
  set_global_variable("PASS_LOS", nil)
  
  # 8. Crear archivo de información del pase
  begin
    pass_info_file = File.join(pass_dir, "pass_info.txt")
    File.open(pass_info_file, 'w') do |f|
      f.puts "INFORMACIÓN DEL PASE"
      f.puts "="*50
      f.puts "Inicio programado: #{pass_start_time.strftime('%Y-%m-%d %H:%M:%S')}"
      f.puts "Duración estimada: #{pass_duration} minutos"
      f.puts "Elevación máxima: #{max_elevation}°"
      f.puts "="*50
    end
    puts "✓ Archivo de información creado"
  rescue => e
    puts "⚠ No se pudo crear archivo de información: #{e.message}"
  end
  
  # 9. Resumen
  puts "\n" + "="*70
  if all_ok
    puts "✓ VERIFICACIÓN PRE-PASE COMPLETADA"
    puts "Sistema listo para contacto"
  else
    puts "⚠ VERIFICACIÓN PRE-PASE COMPLETADA CON ADVERTENCIAS"
    puts "Revisar problemas antes del pase"
  end
  puts "="*70
  
  return all_ok
end
