# Script: pase_automatizado.rb
# Ubicación: config/targets/CUBESAT/lib/scripts/
# Descripción: Secuencia automática para pase de satélite

# 1. Configuración Inicial
radio_target = "MI_RADIO" # El nombre de tu target en cosmos (definido en cmd_tlm_server.txt)
sat_target = "CUBESAT"    # El nombre de tu satélite definido en folders

puts "INICIANDO SECUENCIA DE PASE AUTOMATIZADO"
puts "Hora actual: #{Time.now}"

# Preguntar al operador si está listo (útil para demos)
respuesta = ask("¿Confirmar inicio de seguimiento? (S/N)")
if respuesta != "S"
  puts "Abortando secuencia."
  exit
end

# 2. Preparación (AOS - 2 minutos)
# Mover rotadores (si tuvieras)
# cmd("ROTATOR SET_POS with AZ 0, EL 0")

# Encender grabación de I/Q en GNU Radio (vía comando UDP)
# Suponiendo que definiste un comando en tu target de tierra para activar grabación
cmd("#{radio_target} START_RECORDING")
puts "Grabación iniciada."

# 3. Adquisición de Señal (El bucle principal)
puts "Esperando señal del satélite..."

# Intentamos hacer 'ping' 10 veces
10.times do |i|
  # Enviar comando de Ping
  cmd("#{sat_target} PING")
  
  # Esperar 1 segundo entre intentos
  wait(1)
  
  # Verificar si cambió el contador de paquetes recibidos
  # 'RECEIVED_COUNT' es una variable interna de COSMOS para cada interfaz
  if tlm("#{sat_target} HEALTH_PKT RECEIVED_COUNT") > 0
    puts "¡ENLACE CONFIRMADO! Iniciando descarga..."
    
    # 4. Operación Nominal
    cmd("#{sat_target} DUMP_MEMORY")
    
    # Esperar hasta que termine la descarga (o un tiempo fijo)
    wait(30) 
    
    break # Salir del bucle si tenemos éxito
  else
    puts "Intento #{i+1}: Sin respuesta..."
  end
end

# 5. Finalización
cmd("#{radio_target} STOP_RECORDING")
puts "Pase finalizado. Datos guardados en logs."